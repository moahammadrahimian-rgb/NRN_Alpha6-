let alpha6Token=localStorage.getItem("alpha6_token")||"";

async function api(url,options={}){
  options.headers=Object.assign(
    {"Content-Type":"application/json"},
    options.headers||{}
  );

  if(alpha6Token)
    options.headers.Authorization="Bearer "+alpha6Token;

  const r=await fetch(url,options);
  return r.json();
}

function setToken(token){
  alpha6Token=token||"";
  if(alpha6Token)
    localStorage.setItem("alpha6_token",alpha6Token);
  else
    localStorage.removeItem("alpha6_token");
}

async function alpha6Health(){
  return api("/api/system/health");
}
