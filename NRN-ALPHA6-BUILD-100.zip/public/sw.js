const CACHE="alpha6-v1";

self.addEventListener("install",event=>{
  event.waitUntil(
    caches.open(CACHE).then(cache=>cache.addAll([
      "/",
      "/manifest.json"
    ]))
  );
});

self.addEventListener("fetch",event=>{
  event.respondWith(
    caches.match(event.request).then(cached=>{
      return cached||fetch(event.request);
    })
  );
});
