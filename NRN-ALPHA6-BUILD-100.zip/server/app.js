require("dotenv").config();

const express=require("express");
const cors=require("cors");
const helmet=require("helmet");
const path=require("path");

const initDB=require("./database/init");

const authRoutes=require("./routes/authRoutes");
const neuronRoutes=require("./routes/neuronRoutes");
const networkRoutes=require("./routes/networkRoutes");
const referralRoutes=require("./routes/referralRoutes");
const referralCodeRoutes=require("./routes/referralCodeRoutes");
const productRoutes=require("./routes/productRoutes");
const orderRoutes=require("./routes/orderRoutes");
const paymentRoutes=require("./routes/paymentRoutes");
const adsRoutes=require("./routes/adsRoutes");
const listingRoutes=require("./routes/listingRoutes");
const shippingRoutes=require("./routes/shippingRoutes");
const notificationRoutes=require("./routes/notificationRoutes");
const helpRoutes=require("./routes/helpRoutes");
const systemRoutes=require("./routes/systemRoutes");
const deviceRoutes=require("./routes/deviceRoutes");
const security=require("./middleware/security");
const rateLimit=require("./middleware/rateLimit");



const app=express();
const PORT=process.env.PORT||3000;

app.use(helmet({contentSecurityPolicy:false}));\napp.use(security);\napp.use(rateLimit);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.get("/api/health",(req,res)=>{
  res.json({
    ok:true,
    app:"NEURON ALPHA-6",
    status:"online"
  });
});

app.use("/api/auth",authRoutes);
app.use("/api/neurons",neuronRoutes);
app.use("/api/network",networkRoutes);
app.use("/api/referrals",referralRoutes);
app.use("/api/invites",referralCodeRoutes);
app.use("/api/products",productRoutes);
app.use("/api/orders",orderRoutes);
app.use("/api/payments",paymentRoutes);
app.use("/api/ads",adsRoutes);
app.use("/api/listings",listingRoutes);
app.use("/api/shipping",shippingRoutes);
app.use("/api/notifications",notificationRoutes);
app.use("/api/help",helpRoutes);\napp.use("/api/system",systemRoutes);\napp.use("/api/device",deviceRoutes);


app.use(express.static(path.join(__dirname,"../public")));

app.use((req,res)=>{
  res.sendFile(path.join(__dirname,"../public/index.html"));
});

initDB().then(()=>{
  app.listen(PORT,"0.0.0.0",()=>{
    console.log("==================================");
    console.log("     NEURON ALPHA-6 ONLINE");
    console.log("     http://127.0.0.1:"+PORT);
    console.log("==================================");
  });
}).catch(err=>{
  console.error(err);
  process.exit(1);
});
