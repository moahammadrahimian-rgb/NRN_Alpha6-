const {createUser}=require("../services/userService");
const {login}=require("../services/authService");

async function register(req,res){
  try{
    const {username,password}=req.body;
    if(!username||!password)
      return res.status(400).json({ok:false,error:"نام کاربری و رمز عبور الزامی است"});
    const user=await createUser(username,password);
    res.json({ok:true,user:{id:user.id,username:user.username}});
  }catch(e){
    res.status(400).json({ok:false,error:"نام کاربری قبلا ثبت شده یا اطلاعات نامعتبر است"});
  }
}

async function signin(req,res){
  const {username,password}=req.body;
  const result=await login(username,password);
  if(!result)
    return res.status(401).json({ok:false,error:"نام کاربری یا رمز عبور نادرست است"});
  res.json({ok:true,...result});
}

module.exports={register,signin};
