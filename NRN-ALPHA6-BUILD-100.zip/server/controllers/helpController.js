async function help(req,res){
 res.json({
  ok:true,
  help:[
   "ثبت‌نام و ورود",
   "ساخت نرون",
   "شبکه و دعوت",
   "محصول و سفارش",
   "تبلیغات",
   "آگهی",
   "ارسال",
   "اعلان‌ها"
  ]
 });
}

module.exports={help};
