const {network}=require("../services/networkService");

async function getNetwork(req,res){
  res.json({ok:true,network:await network(req.user.id)});
}

module.exports={getNetwork};
