const service=require("../services/neuronService");

async function create(req,res){
  const code=await service.create(req.user.id);
  res.json({ok:true,neuron_code:code});
}

async function list(req,res){
  res.json({ok:true,neurons:await service.list(req.user.id)});
}

module.exports={create,list};
