const service=require("../services/notificationService");

async function list(req,res){
 res.json({ok:true,notifications:await service.list(req.user.id)});
}

module.exports={list};
