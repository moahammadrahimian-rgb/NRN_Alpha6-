const service=require("../services/orderService");

async function create(req,res){
 const {productId}=req.body;
 if(!productId)return res.status(400).json({ok:false,error:"productId لازم است"});
 await service.create(req.user.id,productId);
 res.json({ok:true,message:"سفارش ثبت شد"});
}

async function list(req,res){
 res.json({ok:true,orders:await service.list(req.user.id)});
}

module.exports={create,list};
