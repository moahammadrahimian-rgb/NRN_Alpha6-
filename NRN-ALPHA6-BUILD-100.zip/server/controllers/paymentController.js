const service=require("../services/paymentService");

async function create(req,res){
 await service.create(req.user.id,req.body.amount);
 res.json({ok:true,status:"test"});
}

module.exports={create};
