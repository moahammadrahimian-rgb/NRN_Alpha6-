const service=require("../services/productService");

async function create(req,res){
 const {title,price}=req.body;
 if(!title)return res.status(400).json({ok:false,error:"عنوان لازم است"});
 res.json({ok:true,products:await service.create(title,price)});
}

async function list(req,res){
 res.json({ok:true,products:await service.list()});
}

module.exports={create,list};
