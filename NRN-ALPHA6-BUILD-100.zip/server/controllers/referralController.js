const service=require("../services/referralService");

async function attach(req,res){
  const {referredId,code}=req.body;
  if(!referredId||!code)
    return res.status(400).json({ok:false,error:"اطلاعات ناقص است"});
  await service.create(req.user.id,referredId,code);
  res.json({ok:true});
}

module.exports={attach};
