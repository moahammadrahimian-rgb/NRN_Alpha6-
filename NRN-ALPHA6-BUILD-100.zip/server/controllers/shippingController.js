const service=require("../services/shippingService");

async function create(req,res){
 await service.create(
  req.user.id,
  req.body.method,
  req.body.tracking
 );
 res.json({ok:true,message:"اطلاعات ارسال ثبت شد"});
}

module.exports={create};
