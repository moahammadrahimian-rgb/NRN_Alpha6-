const initSqlJs=require("sql.js");
const fs=require("fs");
const path=require("path");

const DB_DIR=path.join(__dirname,"../../database");
const DB_FILE=path.join(DB_DIR,"alpha6.db");

let db=null;

async function getDB(){
  if(db) return db;
  const SQL=await initSqlJs();
  fs.mkdirSync(DB_DIR,{recursive:true});
  if(fs.existsSync(DB_FILE)){
    db=new SQL.Database(fs.readFileSync(DB_FILE));
  }else{
    db=new SQL.Database();
  }
  return db;
}

function saveDB(){
  if(!db) return;
  fs.writeFileSync(DB_FILE,Buffer.from(db.export()));
}

module.exports={getDB,saveDB};
