const fs=require("fs");
const path=require("path");
const {getDB,saveDB}=require("./database");

async function migrate(){
 const db=await getDB();
 const dir=path.join(__dirname,"../../database/schema");
 for(const file of fs.readdirSync(dir).sort()){
  if(!file.endsWith(".sql")) continue;
  db.run(fs.readFileSync(path.join(dir,file),"utf8"));
 }
 saveDB();
 console.log("DATABASE MIGRATED");
}
migrate().catch(console.error);
