const jwt=require("jsonwebtoken");

module.exports=function(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer "))
    return res.status(401).json({ok:false,error:"احراز هویت لازم است"});
  try{
    req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);
    next();
  }catch(e){
    res.status(401).json({ok:false,error:"توکن نامعتبر است"});
  }
};
