const hits=new Map();

module.exports=function(req,res,next){
  const key=req.ip+"|"+req.path;
  const now=Date.now();
  const old=hits.get(key)||{time:now,count:0};

  if(now-old.time>60000){
    old.time=now;
    old.count=0;
  }

  old.count++;
  hits.set(key,old);

  if(old.count>120)
    return res.status(429).json({ok:false,error:"درخواست‌های زیاد"});

  next();
};
