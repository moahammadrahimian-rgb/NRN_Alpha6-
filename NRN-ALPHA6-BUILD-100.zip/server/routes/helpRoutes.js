const express=require("express");
const c=require("../controllers/helpController");
const router=express.Router();

router.get("/",c.help);

module.exports=router;
