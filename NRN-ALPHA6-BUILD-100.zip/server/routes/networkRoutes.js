const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/networkController");
const router=express.Router();

router.get("/",auth,c.getNetwork);

module.exports=router;
