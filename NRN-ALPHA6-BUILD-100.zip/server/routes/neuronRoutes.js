const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/neuronController");
const router=express.Router();

router.get("/",auth,c.list);
router.post("/",auth,c.create);

module.exports=router;
