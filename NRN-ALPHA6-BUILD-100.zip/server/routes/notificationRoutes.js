const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/notificationController");
const router=express.Router();

router.get("/",auth,c.list);

module.exports=router;
