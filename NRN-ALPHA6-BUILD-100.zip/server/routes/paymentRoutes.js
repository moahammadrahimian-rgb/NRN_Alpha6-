const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/paymentController");
const router=express.Router();

router.post("/test",auth,c.create);

module.exports=router;
