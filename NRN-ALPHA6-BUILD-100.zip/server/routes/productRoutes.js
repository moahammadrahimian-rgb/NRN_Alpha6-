const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/productController");
const router=express.Router();

router.get("/",c.list);
router.post("/",auth,c.create);

module.exports=router;
