const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/referralController");
const router=express.Router();

router.post("/attach",auth,c.attach);

module.exports=router;
