const express=require("express");
const auth=require("../middleware/auth");
const c=require("../controllers/shippingController");
const router=express.Router();

router.post("/",auth,c.create);

module.exports=router;
