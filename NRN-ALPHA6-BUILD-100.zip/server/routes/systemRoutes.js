const express=require("express");
const c=require("../controllers/systemController");
const router=express.Router();

router.get("/health",c.health);
router.get("/info",c.info);

module.exports=router;
