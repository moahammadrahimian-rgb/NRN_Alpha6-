const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const {findUser}=require("./userService");

async function login(username,password){
  const user=await findUser(username);
  if(!user)return null;
  const valid=await bcrypt.compare(password,user.password);
  if(!valid)return null;
  const token=jwt.sign(
    {id:user.id,username:user.username},
    process.env.JWT_SECRET,
    {expiresIn:"7d"}
  );
  return {token,user:{id:user.id,username:user.username}};
}
module.exports={login};
