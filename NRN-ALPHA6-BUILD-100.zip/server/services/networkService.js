const {getDB}=require("../database/database");

async function network(userId){
  const db=await getDB();
  const r=db.exec(`
    SELECT n.id,n.neuron_code,n.user_id
    FROM neurons n
    WHERE n.user_id=?
  `,[userId]);
  if(!r.length)return [];
  return r[0].values.map(v=>({
    id:v[0],neuron_code:v[1],user_id:v[2]
  }));
}

module.exports={network};
