const {getDB,saveDB}=require("../database/database");
const {neuronId}=require("../utils/id");
const {now}=require("../utils/time");

async function create(userId){
  const db=await getDB();
  const code=neuronId();
  db.run(
    "INSERT INTO neurons(user_id,neuron_code,created_at) VALUES(?,?,?)",
    [userId,code,now()]
  );
  saveDB();
  return code;
}

async function list(userId){
  const db=await getDB();
  const r=db.exec(
    "SELECT id,neuron_code,created_at FROM neurons WHERE user_id=?",
    [userId]
  );
  if(!r.length)return [];
  return r[0].values.map(v=>({
    id:v[0],neuron_code:v[1],created_at:v[2]
  }));
}

module.exports={create,list};
