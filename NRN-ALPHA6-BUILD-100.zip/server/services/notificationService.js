const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function create(userId,message){
 const db=await getDB();
 db.run(
  "INSERT INTO notifications(user_id,message,read,created_at) VALUES(?,?,?,?)",
  [userId,message,0,now()]
 );
 saveDB();
}

async function list(userId){
 const db=await getDB();
 const r=db.exec(
  "SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC",
  [userId]
 );
 if(!r.length)return[];
 return r[0].values.map(v=>({
  id:v[0],user_id:v[1],message:v[2],
  read:v[3],created_at:v[4]
 }));
}

module.exports={create,list};
