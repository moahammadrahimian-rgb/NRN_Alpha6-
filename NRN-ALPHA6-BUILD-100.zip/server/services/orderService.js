const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function create(userId,productId){
 const db=await getDB();
 db.run(
  "INSERT INTO orders(user_id,product_id,status,created_at) VALUES(?,?,?,?)",
  [userId,productId,"pending",now()]
 );
 saveDB();
 return true;
}

async function list(userId){
 const db=await getDB();
 const r=db.exec(
  "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC",
  [userId]
 );
 if(!r.length)return[];
 return r[0].values.map(v=>({
  id:v[0],user_id:v[1],product_id:v[2],
  status:v[3],created_at:v[4]
 }));
}

module.exports={create,list};
