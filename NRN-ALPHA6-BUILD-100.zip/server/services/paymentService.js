const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function create(userId,amount){
 const db=await getDB();
 db.run(
  "INSERT INTO payments(user_id,amount,status,created_at) VALUES(?,?,?,?)",
  [userId,Number(amount)||0,"test",now()]
 );
 saveDB();
 return true;
}

module.exports={create};
