const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function create(referrerId,referredId,code){
  const db=await getDB();
  db.run(
    "INSERT INTO referrals(referrer_id,referred_id,code,created_at) VALUES(?,?,?,?)",
    [referrerId,referredId,code,now()]
  );
  saveDB();
  return true;
}

module.exports={create};
