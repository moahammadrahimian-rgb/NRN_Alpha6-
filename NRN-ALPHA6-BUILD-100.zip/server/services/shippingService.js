const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function create(userId,method,tracking){
 const db=await getDB();
 db.run(`
  CREATE TABLE IF NOT EXISTS shipping_orders(
   id INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id INTEGER,
   method TEXT,
   tracking TEXT,
   created_at TEXT
  )
 `);
 db.run(
  "INSERT INTO shipping_orders(user_id,method,tracking,created_at) VALUES(?,?,?,?)",
  [userId,method||"",tracking||"",now()]
 );
 saveDB();
 return true;
}

module.exports={create};
