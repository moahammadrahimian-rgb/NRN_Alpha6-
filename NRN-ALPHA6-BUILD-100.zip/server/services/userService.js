const bcrypt=require("bcryptjs");
const {getDB,saveDB}=require("../database/database");
const {now}=require("../utils/time");

async function createUser(username,password){
  const db=await getDB();
  const hash=await bcrypt.hash(password,10);
  db.run(
    "INSERT INTO users(username,password,created_at) VALUES(?,?,?)",
    [username,hash,now()]
  );
  saveDB();
  return findUser(username);
}

async function findUser(username){
  const db=await getDB();
  const r=db.exec("SELECT * FROM users WHERE username=?",[username]);
  if(!r.length||!r[0].values.length)return null;
  const v=r[0].values[0];
  return {id:v[0],username:v[1],password:v[2],created_at:v[3]};
}

module.exports={createUser,findUser};
