function ok(res,data={}){
  return res.json({ok:true,data});
}
function fail(res,message="خطا",code=400){
  return res.status(code).json({ok:false,error:message});
}
module.exports={ok,fail};
